import React from "react" 
import "./Header.css"
import { Link } from "react-router-dom"
import {auth, provider } from "../firebase/firebase";
import {Login} from "react"
import { signInWithPopup } from "@firebase/auth";

// import 'firebase/auth';

const handleAuth = () => {
  
  signInWithPopup(auth, provider).then((result) =>{
    console.log(result);
  }).catch((error) => {
    alert(error.message)
  })
}

const Header = () => {
    return (
        <div>
                <div className="header">
                    
                <div className="headerLeft">
                    <Link to="/"> <img className="header_icon" src="https://asset.brandfetch.io/id4J58sqa_/id3secYmRE.svg" /></Link>
                    <Link to="/movies/popular" style={{textDecoration: "none"}}><span>Popular</span></Link>
                    <Link to="/movies/top_rated" style={{textDecoration: "none"}}><span>Top Rated</span></Link>
                    <Link to="/movies/upcoming" style={{textDecoration: "none"}}><span>Upcoming</span></Link>
                    
                </div>
                <div className="right_side">
                    
                    <span className="searchbar">
                      
                    <i class="bi bi-search"></i>Search
                    </span>
                    <span className="heart">
                    <i class="bi bi-heart"></i>
                    </span>


                    <span className="login">
                    <Login onclick={handleAuth}><i class="bi bi-person-fill"></i>Login</Login>
                    {/* <login ><i class="bi bi-person-fill"></i>Login</login> */}
                    </span>
                   
                </div>
                
                
            </div>
            <hr
        style={{
          background: 'black',
        //   color: 'black',
        //   borderColor: 'black',
          height: '1px',
        }}
      />
      <div>
      
      </div>
      </div>
     
                 
    )
}

export default Header